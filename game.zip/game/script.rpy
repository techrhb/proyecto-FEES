﻿# Coloca el código de tu juego en este archivo.

# Format: image [name] = "[filename.png]"
image Isa = "Isa1.png"
image Isa3 = "Isapregunta.png"
image bg room = "UCR1.jpg"
image pretil = "pretil.jpeg"
image logo = "logoucr.png"
image Isa2 = "Isa2.png"
image Isa4 = "Isa4.png"
image Isa5 = "Isa5.png"
image Mateo = "Mateosaluda1.png"
image Mateo2 = "Mateosexplica.png"
image Profe = "profe1.png"
image cafe = "cafeteria.png"
image cafe2 = "cafeteria2.png"
image despedida = "despedida.png"

# Declara los personajes usados en el juego

define I = Character("Isabel")
define M = Character("Mateo")
define P = Character("Pablo")
define V = Character("Valeria")

# Transformación para el efecto de cine
# 'velocidad' es el tiempo que tarda en cruzar la pantalla
transform efecto_subir(velocidad):
    yanchor 0.0 
    ypos 1.1      # Empieza justo debajo de la pantalla
    linear velocidad ypos -1.1  # Termina justo arriba de la pantalla

# Pantalla dedicada para texto centrado

transform efecto_subir(velocidad):
    yanchor 0.5
    xalign 0.5 
    ypos 1.5    
    linear 5.0 ypos 0.5
    pause 5.0
    linear 5.0 ypos -0.5
    
screen mi_cuadro_centro(texto_linea1, texto_linea2="", texto_linea3="", _at=None):
    
    frame:
        background "#000000cc"      # Fondo negro con transparencia
        xsize 700                   # Ancho 
        ysize 400                   # Alto cerrado
        align (0.5, 0.5)            # ¡Centrado absoluto en pantalla!
        padding (40, 40)            # Margen interno para el texto
        
        # Aplicamos el efecto si se lo enviamos
        at _at 

        vbox:
            align (0.5, 0.5)
            spacing 20              # Espacio entre líneas de texto

            # Línea 1 (Siempre aparece)
            text texto_linea1:
                color "#ffffff"
                xalign 0.5
                text_align 0.5

            # Línea 2 (Aparece solo si tiene texto)
            if texto_linea2 != "":
                text texto_linea2:
                    color "#ffffff"
                    xalign 0.5
                    text_align 0.5

            # Línea 3 (Aparece solo si tiene texto)
            if texto_linea3 != "":
                text texto_linea3:
                    color "#ffffff"
                    xalign 0.5
                    text_align 0.5


# Transformación "big y big2"
transform big:
    zoom 2.5 # Esto la hace 2.5 veces su tamaño original
transform big2:
    zoom 1.5 # Esto la hace 1.5 veces su tamaño original
  
# Opción alternativa: Llena la pantalla manteniendo la proporción original de la foto
image bg room = Transform("UCR1.jpg", xysize=(1920, 1080))

# Opción alternativa: Llena la pantalla manteniendo la proporción original de la foto
image pretil = Transform("pretil.jpeg", xysize=(1920, 1080))

# Transformación
transform mover_logo:
    # Tamaño del logo: reduce el 0.3 al valor que ocupe el espacio que deseas (ej. 15% o 30%)
    zoom 1.0 
    
    # POSICIÓN INICIAL: Esquina inferior izquierda
    # (xalign e yalign van de 0.0 a 1.0. 0.0 es izquierda/arriba, 1.0 es derecha/abajo)
    xalign 0.0
    yalign 1.0
    
    # MOVIMIENTO LENTO hacia la posición final
    # linear 5.0 significa que tardará 5 segundos en completar el trayecto
    linear 5.0 xalign 0.95 yalign 0.05  # Posición final: Esquina superior derecha (con un pequeño margen)
 
 # ==========================================
 # SALTAR EL MENÚ PRINCIPAL AL ARRANCAR
 # ==========================================

label splashscreen:
    # Este comando borra cualquier rastro de la interfaz del menú
    $ renpy.free_memory()
    
    scene black
    
    # Muestra la pantalla usando la transformación 'efecto_subir'
    # Da 8 segundos para que sea un movimiento pausado y elegante
    show screen mi_cuadro_centro("UNIVERSIDAD DE COSTA RICA, ESCUELA DE BIBLIOTECOLOGÍA Y CIENCIAS DE LA INFORMACIÓN", "Presentan:", "El FEES y la Educación Superior", _at=efecto_subir(8.0))
    
    # Pausar el mismo tiempo que dura la animación (15 seg)
    $ renpy.pause(15.0)
    hide screen mi_cuadro_centro
    jump start
    
    # Pantalla especial de créditos que acepta imágenes y texto

screen creditos(_at=None):
    frame:
        background "#000000cc"      # Fondo negro con transparencia
        xsize 800                   # La hacemos un poco más ancha para que quepan los logos
        ysize 550                   # Un poco más alta para organizar los elementos
        align (0.5, 0.5)            # Centrado absoluto
        padding (40, 30)
        
        at _at                      # Aplica la animación de cine

        # Organiza todo en una columna vertical centrada
        vbox:
            align (0.5, 0.5)
            spacing 15              # Espacio entre cada elemento

            # 1. LOGO PRINCIPAL
            add "logoucr.png" xalign 0.5 zoom 0.8 # Puedes ajustar el 'zoom' si se ve muy grande

            # 2. TEXTOS DE CRÉDITOS
            text "CRÉDITOS Y DERECHOS DE AUTOR" color "#ffffff" size 26 xalign 0.5
            text "Desarrollado por el Lic. Rolando Herrera Burgos y la Escuela de Bibliotecología y Ciencias de la Información. 2026" color "#ffffff" size 20 xalign 0.5
            text "Bajo la licencia Creative Commons Atribución-CompartirIgual. Para ver una copia de esta licencia, visite https://creativecommons.org/licenses/by/4.0/ " color "#ffffff" size 18 xalign 0.5
            
            # Espacio vacío de separación
            null height 10 

            # 3. IMAGEN DE LICENCIA CREATIVE COMMONS
            # add "licencia_cc.png" xalign 0.5
 
# El juego comienza aquí.
label start:

    # Muestra una imagen de fondo: Aquí se usa un marcador de posición por
    # defecto. Es posible añadir un archivo en el directorio 'images' con el
    # nombre "bg room.png" or "bg room.jpg" para que se muestre aquí.

    scene bg room with dissolve

    # Muestra un personaje: Se usa un marcador de posición. 
   
    # show logo at mover_logo
    show Isa at big, left with dissolve
   
    # Presenta las líneas del diálogo.

    I "Hola, ¿pura vida?, me llamo Isabel, estás en una animación para que aprendamos sobre el FEES, haz clic para continuar."
    
    # Al hacer clic aquí, Isa se moverá a la derecha de forma fluida
    show Isa at big, right with ease

    I "Yo y mis compas, queremos hablar del FEES y de la U, vamos a darte la información de forma clara y entretenida"
    hide Isa
    
    show Isa2 at big2, left with dissolve
    hide Isa2
    show Isa2 at big, center with ease
    
    I "Lo primero que vamos a hacer, es explicarte qué es el FEES y por qué existe, para eso vamos a llamar a Mateo. Andaba por acá, en Generales."
    I "Mateo, mae, vení, ocupamos que nos hables del FEES."
    M "Mae, ya llego, suave un toque."
    I "Quedate allí, mejor nos vamos para el Pretil."
    hide Isa2
   
    # Aparece Mateo: explica porque existe el FEES y qué es
    
    scene pretil with dissolve
    
    show Mateo at big, center with dissolve
    
    M "Ya llegué, vengo de la Biblioteca."
    M "¡Qué dicha que me preguntan por FEES, yo no sabía mucho tampoco, pero me informé!"
    M "Voy a darles algunos datos que he logrado averiguar."
    hide Mateo with dissolve
    
    # Muestra un cuadro de dialogo
    
    show screen mi_cuadro_centro ("El FEES es el fondo de la especial de la educación superior. Es dado por el estado para financiar la Educación Superior Pública,")
    $ renpy.pause(5.0)
    show screen mi_cuadro_centro ("esto es la UCR, ITCR, UNA, UNED y UTN.Está garantizado en la Constitución Política en los artículos 78, 84 y 85.")
    $ renpy.pause(5.0)
    show screen mi_cuadro_centro ("En primer lugar, la Educación Pública es un derecho, y el estado debe asignar el 8% del PIB (Art.78)")
    $ renpy.pause(5.0)
    hide screen mi_cuadro_centro
    
    show Mateo2 at big2, left with dissolve
    
    M "Ves Isa, el FEES es un aporte que hace el Estado para financiar la Educación Superior Pública."
    
    show Isa3 at big, center with dissolve
    
    I "Pero Mateo, ¿ese monto es igual cada año o tiene que aumentar?"
    M "No Isa, el monto por ley no puede ser inferior al del año anterior, pero cada año el costo de las cosas aumenta (combustible, electricidad, papelería), por eso las universidades negocian un aumento, el monto no tiene un porcentaje de ley fijo sobre el Producto Interno Bruto (PIB),"
    M "pero históricamente las universidades públicas y los rectores (CONARE) han establecido una meta aspiracional del 1,5%% del PIB, ligada al mandato constitucional que exige invertir el 8%% del PIB en educación."
    hide Mateo2
    hide Isa3
    
    show Isa4 at big, left with ease
    I "Mateo, mirá quien viene, es la Profe Vale, ella sabe más, podemos preguntarle."
    hide Isa4
    show Isa at big, center with ease
    I "Profeeeeee, venga, ocupamos hacer unas preguntas."
    hide Isa
    
    show Profe at big, left with ease
    
    V "Hola, ¿cómo les va?,¿en qué andan?"
    hide Profe
    show Isa5 at big, center with dissolve
    I "Profe, tenemos muchas dudas del FEES."
    
    show Mateo2 at big2, right with ease
    M "Sí profe, ¿usted nos puede explicar?"
    hide Mateo2
    hide Isa5
    
    show Profe at big, center with dissolve
    V "Claro, con mucho gusto, vamos a la soda por un café, yo invito."
    hide Profe
    
    show cafe at center with dissolve
    V "Muy bien, ¿cuáles son las preguntas?"
    
    # El menú empieza aquí usando una etiqueta para poder regresar a él
label menu_preguntas:

    # Menú de opciones de Ren'Py
    menu:
        "¿Qué les gustaría saber?":
            jump menu_preguntas # Esto es solo el título o texto guía del menú

        "1. ¿Cómo se usa el FEES?":
            jump respuesta_1

        "2. ¿Es cierto que se reparte igual entre todas las Universidades?":
            jump respuesta_2

        "3. ¿Por qué es importante para las becas?":
            jump respuesta_3

        "4. ¿Cómo beneficia a la investigación en el país?":
            jump respuesta_4 # Nota: puedes llamarle respuesta_4, mantengamos el orden: jump respuesta_4

        "5. ¿Qué pasaría si el FEES se reduce o desaparece?":
            jump respuesta_5

        "Listo profe, gracias por explicarnos (Continuar)":
            jump continuar_juego


# ==========================================
# BLOQUES DE RESPUESTAS Y RETORNO
# ==========================================

label respuesta_1:
    M "El FEES se invierte en muchas cosas."
    M "Docencia, lo que incluye becas, pero también en proyectos de investigación y acción social."
    M "Desarrollo de infraestructura y regionalización, de esa forma se aumenta la cobertura de la educación superior pública."
    # Este comando nos devuelve al menú principal:
    jump menu_preguntas

label respuesta_2:
    M "Lo reciben las 5 universidades públicas del país: la UCR, la UNA, el ITCR, la UNED y la UTN."
    M "También financia a CONARE, que es el órgano que las coordina a todas."
    M "No se reparte igual, porque las universidades son diferentes, por ejemplo la UCR es la más grande."
    jump menu_preguntas

label respuesta_3:
    M "¡Es vital! Gran parte del FEES se destina directamente a los sistemas de becas socioeconómicas."
    M "Gracias a esto, miles de estudiantes de zonas rurales o de bajos recursos pueden tener residencia, comedor y dinero para sus estudios."
    M "Pero, también el FEES ayuda a que los costos de matrícula y otros sean muy bajos para los estudiantes a los que no se les asigna beca."
    M "Por ejemplo, el FEES permite que exista un tope de créditos a cobrar, aunque el estudiante esté cursando más materias."
    jump menu_preguntas

label respuesta_4:
    M "Las universidades públicas realizan más del 80%% de la investigación científica en Costa Rica."
    M "El FEES financia laboratorios, proyectos de salud, agricultura y tecnología que ayudan a todo el país."
    jump menu_preguntas

label respuesta_5:
    hide cafe
    show cafe2 at center with dissolve
    M "Si se reduce, se pone en riesgo la cantidad de cupos para estudiantes nuevos, se recortarían becas y muchos proyectos de investigación tendrían que cerrar."
    M "Incluso, si el FEES desapareciera las universidades tendrían que subir de una manera importante los costos de matrícula, dejando por fuera a muchas personas de bajos recursos. Los proyectos que benefician a las comunidades como Odontología, el PIAM y otros tendrían que cerrar."
    M "El FEES no solo es docencia, es la universidad al servicio de las comunidades, con estudiantes que aportan al país."
    M "Por eso la comunidad universitaria siempre defiende este presupuesto."
    jump menu_preguntas


# ==========================================
# SALIDA DEL MENÚ
# ==========================================

label continuar_juego:
    # Cuando elige la última opción, el juego sale del bucle y sigue aquí:
    hide cafe2
    hide cafe
    show despedida at big, left with dissolve
    I "¡Excelente! Ahora que evacuaste tus dudas sobre el FEES, podés discutirlo en clase con tus profes y con los compas."
    M "Así es, no te quedes con dudas, tenés derecho a saber más."
    I "Ahhh y algo muy importante, la U te necesita, todos somos U, y también hay que reflexionar en su futuro para las nuevas generaciones."
    
# --- INICIO DE CRÉDITOS FINALES ---
    scene black with dissolve
    
    # Llamamos a nuestra nueva pantalla gráfica usando la transformación con pausa central
    show screen creditos #(_at=efecto_subir_pausa)
    
    # El juego espera los 10 segundos exactos que tarda la animación en completarse
    $ renpy.pause(10.0)
    
    # Limpieza final de la pantalla
    hide screen mi_pantalla_creditos    

# Finaliza el juego:    
    $ renpy.quit()
    
